package com.kisan.kisan_android.ui.main;

public class Constants {
    public static final String DB_NAME = "DB_NAME";
    public static final String PHONE_NUMBER = "PHONE_NUMBER";
    public static final String NAME = "NAME";
    final static String ACCOUNT_SID = "AC197ce40be74124fed58f51a9a9ee78da";
    final static String AUTH_TOKEN = "fc005785f5011f9cb9906da2fc7b7b2c";
    final static String MESSAGE_SERVICE_ID = "MGe8ce72b271b3d8d11e68e603963ead14";
    final static String CONTACT_LIST = "CONTACT_LIST";
}
